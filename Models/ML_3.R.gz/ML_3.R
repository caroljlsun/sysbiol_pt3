
# libraries

library(keras)
library(useful)
library(abind)
library(tensorflow)

# global options

setwd("/home/cjls4/feature_vectors/")

# loading data

load("x_train_min_p")
load("x_train_min_n")
load("x_train_plus_p")
load("x_train_plus_n")

load("y_train_min_p")
load("y_train_min_n")
load("y_train_plus_p")
load("y_train_plus_n")

load("x_test_min_p")
load("x_test_min_n")
load("x_test_plus_p")
load("x_test_plus_n")

load("y_test_min_p")
load("y_test_min_n")
load("y_test_plus_p")
load("y_test_plus_n")

# ml

batch_size <- 5
num_classes <- 2
epochs <- 15

img_rows <- 2750
img_cols <- 19

#

x_train <- abind(x_train_min_p, x_train_min_n, x_train_plus_p, x_train_plus_n)
y_train <- c(y_train_min_p, y_train_min_n, y_train_plus_p, y_train_plus_n)

remove(x_train_min_p)
remove(x_train_min_n)
remove(x_train_plus_p)
remove(x_train_plus_n)

x_test <- abind(x_test_min_p, x_test_min_n, x_test_plus_p, x_test_plus_n)
y_test <- c(y_test_min_p, y_test_min_n, y_test_plus_p, y_test_plus_n)


##### temporary fix to the NA's problem #####

x_train[is.na(x_train)] <- 0
x_test[is.na(x_test)] <- 0


  
y_train <- to_categorical(y_train, 2)
y_test <- to_categorical(y_test, 2)

#dimensions

dim(x_train) # 2750 19 43826 (rows, col, slices)
dim(y_train) # 43826 


dim(x_test) #
#melt some arrays

x_train <- aperm(x_train, c(3,1,2))
x_test <- aperm(x_test, c(3,1,2))

# check dimensions again

dim(x_train) # 43826 2750 19 (slices, row, col)
dim(y_train) # 43826 2  (slices)

#normalise

x_train <- keras::normalize(x_train, axis = -1, order = 2)
x_test <- keras::normalize(x_test, axis = -1, order = 2)


# Redefine  dimension of train/test inputs

input_shape <- c(img_rows, img_cols)


# the deepG4 paper uses a ff nn
# 1st layer 1D convolutional layer, 900 kernels, kernel size 20bp
# 2nd layer local average pooling, pool size 10bp
# 3rd layer global max pooling
# 4th layer drop out for regularisation
# 5th layer dense layer 
# 6th layer activation layer, activation sigmoid

#Hyperparameters including the number of kernels (900), kernel size (20bp), kernel activation (relu),
#pool size (10bp), drop-out (0%), epoch number (20), number of neurons in the dense layer (100) and the optimizer choice (rmsprop) were found by fine-tuning with a random grid.

model <- keras_model_sequential() %>% 
  layer_conv_1d(filters = 1500, kernel_size = 20, activation = 'relu',
                input_shape = input_shape, padding = "same") %>% 
  layer_average_pooling_1d(pool_size = 10) %>% 
  layer_global_max_pooling_1d() %>% 
  layer_dropout(rate = 0) %>% 
  layer_dense(units = 100) %>% 
  layer_dense(units = num_classes, activation = 'sigmoid')
  
# WITH PADDING

# Compile model
model %>% compile(
  loss = loss_binary_crossentropy,
  optimizer = optimizer_adam(),
  metrics = tf$keras$metrics$AUC()
)

# Train model

cnn <- fit(model,
           x_train, y_train,
           batch_size = batch_size,
           epochs = epochs,
           validation_split = 0.2
           )

scores <- model %>% evaluate(
  x_test, y_test, verbose = 1, metrics = tf$keras$metrics$AUC()
)




# Output metrics
cat('Test loss:', scores[[1]], '\n')
cat('Test auc:', scores[[2]], '\n')

#Test loss: 0.507627  
#Test auc: 0.846049 

#save model
setwd("/home/cjls4/ML/")

#model <- load_model_tf("ML_4_model", compile = F)

# save_model_hdf5(object = model, file = "ML_4_model")
# save_model_tf(model, filepath = "ML_4_84AUC_model", include_optimizer = T)

#use this to delete old models

#remove(model)

#remove(scores)

#k_clear_session()


##### plots #####

