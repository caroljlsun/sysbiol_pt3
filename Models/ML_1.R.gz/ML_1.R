# 3D CNN with Sigmoid

# libraries

library(keras)
library(useful)
library(abind)
library(tensorflow)

# global options

setwd("/home/cjls4/feature_vectors/")

# loading data

load("x_train_min_p")
load("x_train_min_n")
load("x_train_plus_p")
load("x_train_plus_n")

load("y_train_min_p")
load("y_train_min_n")
load("y_train_plus_p")
load("y_train_plus_n")

load("x_test_min_p")
load("x_test_min_n")
load("x_test_plus_p")
load("x_test_plus_n")

load("y_test_min_p")
load("y_test_min_n")
load("y_test_plus_p")
load("y_test_plus_n")

# ml

batch_size <- 5
num_classes <- 2
epochs <- 7

img_rows <- 2750
img_cols <- 19

#

x_train <- abind(x_train_min_p, x_train_min_n, x_train_plus_p, x_train_plus_n)
y_train <- c(y_train_min_p, y_train_min_n, y_train_plus_p, y_train_plus_n)


x_test <- abind(x_test_min_p, x_test_min_n, x_test_plus_p, x_test_plus_n)
y_test <- c(y_test_min_p, y_test_min_n, y_test_plus_p, y_test_plus_n)


##### temporary fix to the NA's problem #####

x_train[is.na(x_train)] <- 0
x_test[is.na(x_test)] <- 0



y_train <- to_categorical(y_train, 2)
y_test <- to_categorical(y_test, 2)

#dimensions

dim(x_train) # 2750 19 43826 (rows, col, slices)
dim(y_train) # 43826 

#melt some arrays

x_train <- aperm(x_train, c(3,1,2))
x_test <- aperm(x_test, c(3,1,2))

# check dimensions again

dim(x_train) # 43826 2750 19 (slices, row, col)
dim(y_train) # 43826 2  (slices)



#normalise

x_train <- normalize(x_train, axis = -1, order = 2)
x_test <- normalize(x_test, axis = -1, order = 2)


# the issue is that there are NAs in the array, how on earth...


# Redefine  dimension of train/test inputs
x_train <- array_reshape(x_train, c(nrow(x_train), img_rows, img_cols, 1))
x_test <- array_reshape(x_test, c(nrow(x_test), img_rows, img_cols, 1))

input_shape <- c(img_rows, img_cols, 1)



model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 50, kernel_size = c(5,5), activation = 'relu',
                input_shape = input_shape) %>%
  layer_max_pooling_2d() %>%
  layer_dropout(rate = 0) %>%
  layer_flatten() %>%
  layer_dense(units = 100, activation = 'sigmoid') %>%
  layer_dense(units = num_classes, activation = 'sigmoid')


# Compile model
model %>% compile(
  loss = loss_binary_crossentropy,
  optimizer = optimizer_adam(),
  metrics = tf$keras$metrics$AUC()
)

# Train model
model %>% fit(
  x_train, y_train,
  batch_size = batch_size,
  epochs = epochs,
  validation_split = 0.2
)


scores <- model %>% evaluate(
  x_test, y_test, verbose = 0
)

# Output metrics
cat('Test loss:', scores[[1]], '\n')
cat('Test accuracy:', scores[[2]], '\n')
 
# > cat('Test loss:', scores[[1]], '\n')
# Test loss: 0.5335646 
# > cat('Test accuracy:', scores[[2]], '\n')
# Test accuracy: 0.7772021 

#save model
setwd("/home/cjls4/ML/")
save_model_hdf5(object = model, file = "ML_1_model")

#use this to delete old models

remove(model)

remove(scores)

k_clear_session()
